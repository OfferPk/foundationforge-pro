# FoundationForge Pro - Technical Architecture & Protocol Specification

## 1. Executive Summary & Purpose
**FoundationForge Pro** is a comprehensive process automation protocol engineering suite specifically targeted at **FOUNDATION Fieldbus H1 (IEC 61158-2 / ISA-50.02)** networks. Foundation Fieldbus is the mission-critical digital bus standard powering global continuous processing facilities: oil refineries, chemical plants, offshore platforms, LNG terminals, and power stations.
This tool automates core physical and scheduling tasks:
1. **Manchester Biphase-L Physical Frame Engine**: Models 31.25 kbps MBP signaling, 0xAC Start Delimiter, 0xAD End Delimiter, and CRC-16 Frame Check Sequences ($x^{16} + x^{12} + x^5 + 1$).
2. **5-Byte Process Value (PV) Quality Engine**: Packs and unpacks 4-byte IEEE-754 floating-point values alongside the 1-byte Fieldbus Status byte (Quality: Good, Uncertain, Bad; Limits: High, Low, Constant).
3. **Link Active Scheduler (LAS) Macrocycle Engine**: Automatically schedules deterministic cyclic communication (Time Distribution, Compelled Data publish broadcasts for AI $\rightarrow$ PID $\rightarrow$ AO) and preserves balanced acyclic Pass Token (PT) windows ($\ge 30\%$) for diagnostic traffic.
4. **Physical Segment Voltage Drop & Spur Sizer**: Models Type A cable loop resistance ($44\ \Omega/\text{km}$), 24V DC power conditioner drops, and individual/cumulative spur constraints to ensure $\ge 9.0\text{V DC}$ terminal voltage at distant field transmitters.
5. **10-Point FF H1 Physical & LAS Safety Auditor**: Verifies permanent address ranges (`0x10..0xF7`), address collisions, 32-device limits, 1900m Type A cable budgets, dual 100-ohm RC bus terminators, and Backup Link Master (LM) redundancy.
6. **DCS Exporter**: Generates Emerson DeltaV / AMS Fieldbus Segment XML definitions, Yokogawa CENTUM VP schedule CSVs, and Python 31.25 kbps virtual bus scripts.

---

## 2. Standards & Physical Layer Specifications
- **IEC 61158-2 / ISA-50.02**: Physical Layer specification for 31.25 kbps Manchester Biphase-L (MBP) fieldbus.
- **FF-890 / FF-891**: Fieldbus Foundation Data Link Layer & Communication Model.
- **FF-940**: Function Block Application Specification (Control in the Field - CIF).
- **IEC 60079-27**: FISCO (Fieldbus Intrinsically Safe Concept) standard for Zone 1 / Class I Div 1 hazardous locations.

---

## 3. Physical Signaling & Framing Format

```
+----------+----+---------+--------+--------+---------+--------+----+
| Preamble | SD | Control | DstAdr | SrcAdr | Payload | FCS-16 | ED |
+----------+----+---------+--------+--------+---------+--------+----+
  2 bytes   1B     1B       1B       1B      Variable   2 bytes  1B
```
- **Preamble**: `0x55 0x55` (Manchester clock synchronization)
- **Start Delimiter (SD)**: `0xAC` (Contains non-data positive/negative violations)
- **Control Byte**: Frame Type (`0x01` CD, `0x02` PT, `0x03` TD, `0x04` PN)
- **Addressing**: Destination and Source Node addresses (`0x10..0xF7` permanent field devices)
- **Payload**: e.g., 5-byte Process Value (Float32 Big-Endian + 1-byte Status)
- **Frame Check Sequence (FCS)**: CRC-16 with generator polynomial $0\text{x}1021$ ($x^{16} + x^{12} + x^5 + 1$), initialized to `0xFFFF`.
- **End Delimiter (ED)**: `0xAD`

---

## 4. Segment Voltage Drop Mathematical Model

For a trunk of length $L_{\text{trunk}}$ and total connected devices $N$:

$$R_{\text{trunk}} = \frac{L_{\text{trunk}}}{1000} \times R_{\text{loop}} \quad (\text{where } R_{\text{loop}} = 44.0\ \Omega/\text{km for Type A cable})$$

$$\Delta V_{\text{trunk}} = I_{\text{total}} \times R_{\text{trunk}} = \left( \sum_{i=1}^{N} I_i \right) \times R_{\text{trunk}}$$

For the most distant device located on a spur of length $L_{\text{spur}}$:
$$\Delta V_{\text{spur}} = I_{\text{device}} \times \left( \frac{L_{\text{spur}}}{1000} \times R_{\text{loop}} \right)$$

$$V_{\text{device}} = V_{\text{PSU}} - \Delta V_{\text{trunk}} - \Delta V_{\text{spur}}$$

The safety boundary mandates $V_{\text{device}} \ge 9.0\text{V DC}$ under all load conditions.
