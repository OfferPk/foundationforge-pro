# FoundationForge Pro - User Guide & Operator Manual

## 1. Quick Start
To launch the interactive web studio:
1. Open `product_197/source-code/index.html` in any modern web browser.
2. All components run completely client-side with zero external internet dependencies or complex installations.

To use the standalone Python CLI:
```bash
# Make CLI executable
chmod +x product_197/build/fieldbus-cli.py

# Build an H1 Compelled Data (CD) Frame for Node 0x14 with PV = 75.5
./product_197/build/fieldbus-cli.py frame-build --dst 0x14 --src 0x01 --type 1 --pv 75.5

# Dissect a raw H1 hex frame
./product_197/build/fieldbus-cli.py frame-dissect "55 55 AC 01 14 01 42 97 00 00 80 69 DE AD"

# Calculate an LAS Macrocycle Schedule for distributed control loops
./product_197/build/fieldbus-cli.py schedule --loops '[{"tag":"FIC-101","ai":25,"pid":35,"ao":25},{"tag":"PIC-102","ai":20,"pid":30,"ao":25}]' --target 1000

# Run 10-Point FF H1 Physical & LAS Safety Auditor
./product_197/build/fieldbus-cli.py audit --devices '[{"addr":20,"spur":30,"ma":22,"lm":true},{"addr":21,"spur":25,"ma":20,"lm":false}]' --trunk 600 --psu 24.0
```

---

## 2. Workbench Tabs & Capabilities

### Tab 1: H1 Frame Dissector & PV Encoder
- Encode 4-byte IEEE-754 floating-point process values alongside 1-byte Fieldbus status bytes (`0x80` Good Non-Cascade, `0xC0` Good Cascade, `0x40` Uncertain, `0x00` Bad).
- Formats complete 31.25 kbps H1 frames with Preamble (`0x5555`), Start Delimiter (`0xAC`), Destination/Source addresses, CRC-16 FCS, and End Delimiter (`0xAD`).
- Inspects and validates FCS integrity.

### Tab 2: LAS Macrocycle Scheduler
- Build distributed Control in the Field (CIF) loops (AI $\rightarrow$ PID $\rightarrow$ AO).
- Automatically sequences Time Distribution (TD), Compelled Data (CD) publish broadcasts, and preserves acyclic Pass Token (PT) windows for diagnostics.
- Provides visual timeline and cyclic bandwidth load indicators.

### Tab 3: Physical Segment & Voltage Sizer
- Calculates loop resistances across Type A, B, and C fieldbus cables.
- Evaluates worst-case voltage drop at the most distant node against the $9.0\text{V DC}$ threshold.
- Compares individual and cumulative spur line lengths against IEC 61158-2 table limits.

### Tab 4: 10-Point Safety Auditor
- Pre-commissioning verification:
  - Permanent node address space (`0x10..0xF7`) and collision prevention.
  - 32-device segment limit (16 for FISCO).
  - 1900m Type A total cable budget.
  - Spur length limits per device count.
  - Dual 100-ohm RC bus terminators (50-ohm net AC impedance).
  - Terminal voltage and power supply envelope.
  - Cyclic schedule load margin ($\le 70\%$).
  - Backup Link Active Scheduler (Link Master) redundancy.

### Tab 5: DCS & Device Exporter
- Outputs Emerson DeltaV / AMS Fieldbus Segment XML definitions.
- Outputs Yokogawa CENTUM VP H1 Schedule CSV tables.
- Outputs Python 31.25 kbps virtual bus simulation scripts.
