/**
 * FoundationForge Pro - 10-Point FF H1 Physical & LAS Safety Auditor
 * Enforces IEC 61158-2 and Fieldbus Foundation (FF-890/FF-940) engineering rules:
 * Node address allocation (0x10..0xF7), 32-device segment limit, 1900m Type A cable limit,
 * individual & cumulative spur length budgets, dual 100-ohm bus terminators,
 * 9.0V DC minimum field device operating voltage, FISCO / Entity safety barrier envelope,
 * Macrocycle schedulability (cyclic load <= 70%), and Link Active Scheduler (LAS) redundancy.
 */

const FieldbusAuditor = (function () {
  const AUDIT_RULES = [
    {
      id: 'FF-01',
      name: 'Node Address Range & Reserved Slots',
      standard: 'FF-890 Section 4.2',
      severity: 'CRITICAL',
      description: 'Permanent field devices must occupy 0x10..0xF7 (16..247). Addresses 0x00..0x0F are reserved for Visitors/LAS, and 0xF8..0xFB are default uncommissioned.'
    },
    {
      id: 'FF-02',
      name: 'Duplicate Device Node Address Check',
      standard: 'IEC 61158-2 Data Link Layer',
      severity: 'CRITICAL',
      description: 'Duplicate node addresses prevent Pass Token rotation, cause data collision, and halt VCR communication.'
    },
    {
      id: 'FF-03',
      name: 'Maximum 32-Device Electrical Load Limit',
      standard: 'IEC 61158-2 Physical Layer',
      severity: 'ERROR',
      description: 'A single H1 segment must never exceed 32 physical transceivers (16 typically recommended in IS hazardous areas).'
    },
    {
      id: 'FF-04',
      name: 'Maximum Total Cable Length (1900m Type A)',
      standard: 'IEC 61158-2 Table 8',
      severity: 'ERROR',
      description: 'Total cable length (Trunk + all Spurs combined) must not exceed 1900 meters for standard Type A shielded twisted pair.'
    },
    {
      id: 'FF-05',
      name: 'Individual Spur Length Limit (Device Count Sized)',
      standard: 'IEC 61158-2 Table 10',
      severity: 'WARNING',
      description: 'Maximum individual spur length must not exceed limits: 120m (<=12 devices), 90m (13-14), 60m (15-18), 30m (19-24).'
    },
    {
      id: 'FF-06',
      name: 'Dual 100-Ohm RC Bus Terminator Verification',
      standard: 'IEC 61158-2 Section 12.7',
      severity: 'CRITICAL',
      description: 'Exactly two terminators (100 Ω resistor in series with 1 µF capacitor) required at physical trunk far ends (50 Ω equivalent AC load).'
    },
    {
      id: 'FF-07',
      name: 'Minimum 9.0V DC Operating Voltage at Worst-Case Node',
      standard: 'IEC 61158-2 Power Specifications',
      severity: 'CRITICAL',
      description: 'Voltage at the terminal of the most distant field transmitter must never drop below 9.0V DC under full segment loop current.'
    },
    {
      id: 'FF-08',
      name: 'Macrocycle Schedulability & Cyclic Load Margin (<= 70%)',
      standard: 'FF-940 Control in the Field',
      severity: 'WARNING',
      description: 'Scheduled cyclic execution and CD broadcasts should consume <= 70% of macrocycle, preserving >= 30% for acyclic Pass Token (PT) diagnostics.'
    },
    {
      id: 'FF-09',
      name: 'FISCO / Entity Intrinsic Safety Current Limit',
      standard: 'IEC 60079-27 / FISCO Model',
      severity: 'WARNING',
      description: 'For Zone 1 / Class I Div 1 installations, segment current must not exceed FISCO barrier limits (typically 110-215 mA).'
    },
    {
      id: 'FF-10',
      name: 'Backup Link Active Scheduler (LAS) Redundancy',
      standard: 'FF-890 Data Link Layer',
      severity: 'INFO',
      description: 'At least one field device should be configured as a Link Master (LM) with Backup LAS capability to maintain control in the field if DCS fails.'
    }
  ];

  /**
   * Run the 10-Point Safety Audit on an H1 network segment
   * @param {Object} config - {
   *   devices: [ { address, name, currentMa, spurLengthM, isLinkMaster } ],
   *   trunkLengthM: number,
   *   cableType: 'TYPE_A',
   *   psuVoltage: number,
   *   terminatorsInstalled: number,
   *   macrocycleMs: number,
   *   cyclicScheduledMs: number,
   *   isFiscoZone1: boolean
   * }
   */
  function auditSegment(config) {
    const devices = config.devices || [];
    const trunkM = config.trunkLengthM || 600;
    const psuVolts = config.psuVoltage || 24.0;
    const terminators = config.terminatorsInstalled !== undefined ? config.terminatorsInstalled : 2;
    const macrocycleMs = config.macrocycleMs || 1000;
    const cyclicMs = config.cyclicScheduledMs || 350;
    const isFisco = config.isFiscoZone1 === true;

    const findings = [];
    let passCount = 0;
    let warnCount = 0;
    let failCount = 0;

    // 1. Address Range Check (0x10..0xF7)
    const invalidAddrs = devices.filter(d => d.address < 0x10 || d.address > 0xF7);
    if (invalidAddrs.length > 0) {
      findings.push({
        id: 'FF-01',
        status: 'FAIL',
        severity: 'CRITICAL',
        details: `Invalid node addresses: ${invalidAddrs.map(d => `0x${d.address.toString(16).toUpperCase()}`).join(', ')}. Standard permanent range is 0x10..0xF7 (16..247).`
      });
      failCount++;
    } else {
      findings.push({
        id: 'FF-01',
        status: 'PASS',
        severity: 'INFO',
        details: 'All field devices configured in legitimate permanent node address space (0x10..0xF7).'
      });
      passCount++;
    }

    // 2. Duplicate Address Check
    const addrs = devices.map(d => d.address);
    const dups = [...new Set(addrs.filter((a, i) => addrs.indexOf(a) !== i))];
    if (dups.length > 0) {
      findings.push({
        id: 'FF-02',
        status: 'FAIL',
        severity: 'CRITICAL',
        details: `Duplicate node addresses detected: ${dups.map(a => `0x${a.toString(16).toUpperCase()}`).join(', ')}. Severe token ring corruption risk.`
      });
      failCount++;
    } else {
      findings.push({
        id: 'FF-02',
        status: 'PASS',
        severity: 'INFO',
        details: 'Zero address collisions detected. Each device possesses a unique link address.'
      });
      passCount++;
    }

    // 3. Max 32-Device Limit
    const maxDevAllowed = isFisco ? 16 : 32;
    if (devices.length > maxDevAllowed) {
      findings.push({
        id: 'FF-03',
        status: 'FAIL',
        severity: 'ERROR',
        details: `Device count (${devices.length}) exceeds maximum limit (${maxDevAllowed} devices${isFisco ? ' for FISCO Zone 1' : ''}).`
      });
      failCount++;
    } else {
      findings.push({
        id: 'FF-03',
        status: 'PASS',
        severity: 'INFO',
        details: `Device count is ${devices.length}/${maxDevAllowed} (compliant with transceiver electrical load).`
      });
      passCount++;
    }

    // 4. Total Cable Length (1900m for Type A)
    const totalSpurM = devices.reduce((sum, d) => sum + (d.spurLengthM || 0), 0);
    const totalCableM = trunkM + totalSpurM;
    if (totalCableM > 1900) {
      findings.push({
        id: 'FF-04',
        status: 'FAIL',
        severity: 'ERROR',
        details: `Total cable length (${totalCableM}m = ${trunkM}m trunk + ${totalSpurM}m spurs) exceeds 1900m Type A maximum.`
      });
      failCount++;
    } else {
      findings.push({
        id: 'FF-04',
        status: 'PASS',
        severity: 'INFO',
        details: `Total cable length (${totalCableM}m) compliant with 1900m Type A standard.`
      });
      passCount++;
    }

    // 5. Individual Spur Length Budget
    let maxAllowedSpur = 120;
    if (devices.length > 18) maxAllowedSpur = 30;
    else if (devices.length > 14) maxAllowedSpur = 60;
    else if (devices.length > 12) maxAllowedSpur = 90;

    const longSpurs = devices.filter(d => (d.spurLengthM || 0) > maxAllowedSpur);
    if (longSpurs.length > 0) {
      findings.push({
        id: 'FF-05',
        status: 'WARN',
        severity: 'WARNING',
        details: `Spur exceedance on devices: ${longSpurs.map(d => `${d.name} (${d.spurLengthM}m)`).join(', ')}. Maximum allowed for ${devices.length} devices is ${maxAllowedSpur}m.`
      });
      warnCount++;
    } else {
      findings.push({
        id: 'FF-05',
        status: 'PASS',
        severity: 'INFO',
        details: `All individual spur lines are within the ${maxAllowedSpur}m limit for ${devices.length} devices.`
      });
      passCount++;
    }

    // 6. Bus Terminators (Exactly 2)
    if (terminators !== 2) {
      findings.push({
        id: 'FF-06',
        status: 'FAIL',
        severity: 'CRITICAL',
        details: `Termination fault: ${terminators} terminators detected. Exactly two 100-ohm RC terminators required at trunk ends.`
      });
      failCount++;
    } else {
      findings.push({
        id: 'FF-06',
        status: 'PASS',
        severity: 'INFO',
        details: 'Dual 100-ohm RC bus terminators confirmed (50-ohm AC characteristic impedance).'
      });
      passCount++;
    }

    // 7. Minimum 9.0V DC Operating Voltage
    const totalCurrentMa = devices.reduce((sum, d) => sum + (d.currentMa || 20), 0);
    const trunkRes = (trunkM / 1000.0) * 44.0;
    const trunkDrop = (totalCurrentMa / 1000.0) * trunkRes;
    const longestSpur = Math.max(...devices.map(d => d.spurLengthM || 0), 0);
    const spurRes = (longestSpur / 1000.0) * 44.0;
    const spurDrop = 0.024 * spurRes;
    const minVolts = parseFloat((psuVolts - trunkDrop - spurDrop).toFixed(2));

    if (minVolts < 9.0) {
      findings.push({
        id: 'FF-07',
        status: 'FAIL',
        severity: 'CRITICAL',
        details: `Worst-case node voltage (${minVolts}V DC) is below minimum 9.0V DC threshold! Devices will brown out or reboot.`
      });
      failCount++;
    } else {
      findings.push({
        id: 'FF-07',
        status: 'PASS',
        severity: 'INFO',
        details: `Worst-case node voltage is ${minVolts}V DC (>= 9.0V DC standard operational threshold).`
      });
      passCount++;
    }

    // 8. Macrocycle Schedulability (<= 70% cyclic)
    const cyclicRatio = (cyclicMs / macrocycleMs) * 100.0;
    if (cyclicRatio > 70.0) {
      findings.push({
        id: 'FF-08',
        status: 'WARN',
        severity: 'WARNING',
        details: `Cyclic schedule consumes ${cyclicRatio.toFixed(1)}% of macrocycle (> 70% threshold). Insufficient acyclic window for diagnostics.`
      });
      warnCount++;
    } else {
      findings.push({
        id: 'FF-08',
        status: 'PASS',
        severity: 'INFO',
        details: `Cyclic schedule load is ${cyclicRatio.toFixed(1)}% (<= 70%), preserving ${ (100 - cyclicRatio).toFixed(1) }% for acyclic Pass Token (PT) communications.`
      });
      passCount++;
    }

    // 9. FISCO Current Limit Check
    if (isFisco && totalCurrentMa > 115) {
      findings.push({
        id: 'FF-09',
        status: 'WARN',
        severity: 'WARNING',
        details: `Segment current (${totalCurrentMa} mA) exceeds typical IIC FISCO barrier rating (110-115 mA).`
      });
      warnCount++;
    } else {
      findings.push({
        id: 'FF-09',
        status: 'PASS',
        severity: 'INFO',
        details: `Current consumption (${totalCurrentMa} mA) is safe${isFisco ? ' within FISCO envelope' : ''}.`
      });
      passCount++;
    }

    // 10. Backup LAS Redundancy
    const linkMasters = devices.filter(d => d.isLinkMaster === true);
    if (linkMasters.length === 0) {
      findings.push({
        id: 'FF-10',
        status: 'WARN',
        severity: 'INFO',
        details: 'No Backup Link Active Scheduler (Link Master) device detected on segment. LAS failure will halt control in the field.'
      });
      warnCount++;
    } else {
      findings.push({
        id: 'FF-10',
        status: 'PASS',
        severity: 'INFO',
        details: `Backup Link Master configured (${linkMasters.map(d => d.name).join(', ')}). High availability preserved.`
      });
      passCount++;
    }

    const overallScore = Math.max(0, 100 - (failCount * 25) - (warnCount * 10));
    const grade = overallScore >= 90 ? 'A (FOUNDATION FIELDBUS CERTIFIED)' : (overallScore >= 75 ? 'B (COMPLIANT WITH WARNINGS)' : 'C (ACTION REQUIRED)');

    return {
      rules: AUDIT_RULES,
      findings,
      summary: {
        totalRules: AUDIT_RULES.length,
        passCount,
        warnCount,
        failCount,
        overallScore,
        grade
      }
    };
  }

  return {
    AUDIT_RULES,
    auditSegment
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FieldbusAuditor;
}
