/**
 * FoundationForge Pro - Link Active Scheduler (LAS) & Macrocycle Schedule Engine
 * Calculates deterministic Macrocycles, Function Block execution offsets (AI -> PID -> AO),
 * Compelled Data (CD) broadcast publication windows, Pass Token (PT) acyclic slots,
 * and Network Bandwidth Utilization at 31.25 kbps.
 */

const FieldbusScheduler = (function () {
  /**
   * Generates a deterministic Macrocycle Schedule for a list of control loops.
   * @param {Array} loops - Array of control loop objects:
   *   [
   *     {
   *       loopId: 'FIC-101',
   *       name: 'Primary Flow Control',
   *       aiDevice: 'FT-101 (Address 0x14)',
   *       pidDevice: 'FIC-101 (Address 0x15)',
   *       aoDevice: 'FV-101 (Address 0x16)',
   *       aiDurationMs: 25,
   *       pidDurationMs: 35,
   *       aoDurationMs: 25
   *     }
   *   ]
   * @param {number} targetMacrocycleMs - e.g. 500ms or 1000ms
   */
  function buildMacrocycleSchedule(loops, targetMacrocycleMs = 1000) {
    let currentOffsetMs = 10; // 10ms initial network clock synchronization window
    const scheduledEvents = [];

    // Schedule Time Distribution (TD) at start of cycle
    scheduledEvents.push({
      timeOffsetMs: 0,
      durationMs: 10,
      type: 'MANAGEMENT',
      eventType: 'Time Distribution (TD)',
      description: 'LAS broadcasts network synchronization clock (TD)'
    });

    for (const loop of loops) {
      // 1. AI Execution
      const aiStart = currentOffsetMs;
      const aiDur = loop.aiDurationMs || 25;
      scheduledEvents.push({
        timeOffsetMs: aiStart,
        durationMs: aiDur,
        type: 'EXECUTION',
        eventType: `${loop.loopId}: AI Execution`,
        device: loop.aiDevice,
        description: `Transducer sampling & scaling in ${loop.aiDevice}`
      });
      currentOffsetMs += aiDur;

      // 2. Compelled Data (CD) Publish from AI to PID
      const cd1Start = currentOffsetMs;
      const cd1Dur = 15; // ~15ms for CD broadcast + publish response
      scheduledEvents.push({
        timeOffsetMs: cd1Start,
        durationMs: cd1Dur,
        type: 'COMMUNICATION',
        eventType: `${loop.loopId}: CD Broadcast (AI -> PID)`,
        device: 'LAS / Publisher',
        description: `LAS sends CD; AI publishes OUT (PV) to VCR publisher link`
      });
      currentOffsetMs += cd1Dur;

      // 3. PID Execution
      const pidStart = currentOffsetMs;
      const pidDur = loop.pidDurationMs || 35;
      scheduledEvents.push({
        timeOffsetMs: pidStart,
        durationMs: pidDur,
        type: 'EXECUTION',
        eventType: `${loop.loopId}: PID Execution`,
        device: loop.pidDevice,
        description: `Algorithm calculation (error, derivative, integral output)`
      });
      currentOffsetMs += pidDur;

      // 4. Compelled Data (CD) Publish from PID to AO
      const cd2Start = currentOffsetMs;
      const cd2Dur = 15;
      scheduledEvents.push({
        timeOffsetMs: cd2Start,
        durationMs: cd2Dur,
        type: 'COMMUNICATION',
        eventType: `${loop.loopId}: CD Broadcast (PID -> AO)`,
        device: 'LAS / Publisher',
        description: `LAS sends CD; PID publishes OUT setpoint to AO block`
      });
      currentOffsetMs += cd2Dur;

      // 5. AO Execution
      const aoStart = currentOffsetMs;
      const aoDur = loop.aoDurationMs || 25;
      scheduledEvents.push({
        timeOffsetMs: aoStart,
        durationMs: aoDur,
        type: 'EXECUTION',
        eventType: `${loop.loopId}: AO Execution`,
        device: loop.aoDevice,
        description: `Final control element positioner & readback output`
      });
      currentOffsetMs += aoDur;
    }

    const scheduledTimeMs = currentOffsetMs;
    const macrocycleMs = Math.max(scheduledTimeMs + 50, targetMacrocycleMs);
    const unscheduledSlotMs = macrocycleMs - scheduledTimeMs;

    // Acyclic Pass Token (PT) time slot for client/server & diagnostics
    scheduledEvents.push({
      timeOffsetMs: scheduledTimeMs,
      durationMs: unscheduledSlotMs,
      type: 'ACYCLIC_SLOT',
      eventType: 'Pass Token (PT) Unscheduled Window',
      description: `Acyclic parameterization, operator display polling, diagnostics, and Probe Node (PN)`
    });

    const cyclicLoadPercent = parseFloat(((scheduledTimeMs / macrocycleMs) * 100.0).toFixed(1));
    const acyclicLoadPercent = parseFloat(((unscheduledSlotMs / macrocycleMs) * 100.0).toFixed(1));

    return {
      scheduledEvents,
      summary: {
        totalLoops: loops.length,
        macrocycleMs,
        scheduledTimeMs,
        unscheduledSlotMs,
        cyclicLoadPercent,
        acyclicLoadPercent,
        isSchedulable: scheduledTimeMs <= macrocycleMs,
        recommendedMacrocycleMs: Math.ceil(scheduledTimeMs / 100) * 100
      }
    };
  }

  return {
    buildMacrocycleSchedule
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FieldbusScheduler;
}
