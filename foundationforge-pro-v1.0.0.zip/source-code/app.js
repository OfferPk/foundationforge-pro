/**
 * FoundationForge Pro - Web Application Controller
 */

document.addEventListener('DOMContentLoaded', function () {
  // Navigation Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(targetId).classList.add('active');
    });
  });

  // Default Datasets
  let controlLoops = [
    {
      loopId: 'FIC-101',
      name: 'Separator Feed Flow Control',
      aiDevice: 'FT-101 (Coriolis)',
      pidDevice: 'FIC-101 (In FT-101)',
      aoDevice: 'FV-101 (Control Valve)',
      aiDurationMs: 25,
      pidDurationMs: 35,
      aoDurationMs: 25
    },
    {
      loopId: 'PIC-102',
      name: 'Vessel Pressure Feedback Loop',
      aiDevice: 'PT-102 (Pressure Tx)',
      pidDevice: 'PIC-102 (In DCS/LAS)',
      aoDevice: 'PV-102 (Vent Valve)',
      aiDurationMs: 20,
      pidDurationMs: 30,
      aoDurationMs: 25
    }
  ];

  let segmentDevices = [
    { address: 0x14, name: 'FT-101 Coriolis Flow Transmitter', currentMa: 22, spurLengthM: 30, isLinkMaster: true },
    { address: 0x15, name: 'PT-101 Pressure Transmitter', currentMa: 20, spurLengthM: 25, isLinkMaster: false },
    { address: 0x16, name: 'TT-101 Temperature Transmitter', currentMa: 20, spurLengthM: 15, isLinkMaster: false },
    { address: 0x17, name: 'FV-101 Digital Valve Positioner', currentMa: 30, spurLengthM: 20, isLinkMaster: true }
  ];

  // TAB 1: H1 Frame Dissector & PV Encoder
  function renderH1Frame() {
    const val = parseFloat(document.getElementById('pv-value').value) || 0.0;
    const quality = document.getElementById('pv-quality').value;
    const dstStr = document.getElementById('frame-dst').value;
    const srcStr = document.getElementById('frame-src').value;
    const fType = parseInt(document.getElementById('frame-type').value) || 1;

    const dstAddr = dstStr.startsWith('0x') || dstStr.startsWith('0X') ? parseInt(dstStr, 16) : parseInt(dstStr, 10);
    const srcAddr = srcStr.startsWith('0x') || srcStr.startsWith('0X') ? parseInt(srcStr, 16) : parseInt(srcStr, 10);

    const pv = FieldbusEngine.encodeProcessValue(val, quality);
    const frame = FieldbusEngine.buildH1Frame({
      frameType: fType,
      destAddress: dstAddr,
      srcAddress: srcAddr,
      payload: pv.bytes
    });

    document.getElementById('h1-hex-output').innerText = frame.hexString;
    document.getElementById('frame-len-badge').innerText = `${frame.byteLength} Bytes (${frame.durationMs} ms @ 31.25k)`;

    const tbody = document.getElementById('dissect-tbody');
    tbody.innerHTML = `
      <tr><td>Preamble &amp; SD</td><td>0x5555 0xAC</td><td>Manchester Synchronization + Start Delimiter (SD)</td></tr>
      <tr><td>Frame Type</td><td>0x${fType.toString(16).padStart(2, '0').toUpperCase()}</td><td>${frame.frameTypeName}</td></tr>
      <tr><td>Destination / Source</td><td>${frame.destAddressHex} / ${frame.srcAddressHex}</td><td>Device Node Addressing</td></tr>
      <tr><td>PV Payload (Float32)</td><td>${pv.bytes.slice(0, 4).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ')}</td><td>${pv.floatValue.toFixed(4)} Engineering Units</td></tr>
      <tr><td>PV Status Byte</td><td>${pv.statusByte}</td><td>Quality: ${pv.qualityName} (Limit: None)</td></tr>
      <tr><td>FCS &amp; ED</td><td>${frame.fcs} 0xAD</td><td>CRC-16 FCS Valid + End Delimiter (ED)</td></tr>
    `;
  }

  document.getElementById('btn-build-h1').addEventListener('click', renderH1Frame);

  // TAB 2: Macrocycle Scheduler
  function renderLoopsTable() {
    const tbody = document.getElementById('tbody-loops');
    tbody.innerHTML = '';

    controlLoops.forEach((l, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><input type="text" class="form-control" style="width: 100px;" value="${l.loopId}" onchange="updateLoop(${idx}, 'loopId', this.value)"></td>
        <td><input type="text" class="form-control" value="${l.aiDevice}" onchange="updateLoop(${idx}, 'aiDevice', this.value)"></td>
        <td><input type="text" class="form-control" value="${l.pidDevice}" onchange="updateLoop(${idx}, 'pidDevice', this.value)"></td>
        <td><input type="text" class="form-control" value="${l.aoDevice}" onchange="updateLoop(${idx}, 'aoDevice', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 70px;" value="${l.aiDurationMs}" onchange="updateLoop(${idx}, 'aiDurationMs', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 70px;" value="${l.pidDurationMs}" onchange="updateLoop(${idx}, 'pidDurationMs', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 70px;" value="${l.aoDurationMs}" onchange="updateLoop(${idx}, 'aoDurationMs', this.value)"></td>
        <td><button class="btn btn-secondary" style="padding: 4px 8px; color: var(--rose-accent);" onclick="removeLoop(${idx})">✕</button></td>
      `;
      tbody.appendChild(tr);
    });

    renderMacrocycleSchedule();
  }

  window.updateLoop = function (idx, field, val) {
    if (field.includes('Duration')) {
      controlLoops[idx][field] = parseInt(val) || 20;
    } else {
      controlLoops[idx][field] = val;
    }
    renderMacrocycleSchedule();
  };

  window.removeLoop = function (idx) {
    if (controlLoops.length > 1) {
      controlLoops.splice(idx, 1);
      renderLoopsTable();
    }
  };

  document.getElementById('btn-add-loop').addEventListener('click', () => {
    const nextNum = controlLoops.length + 1;
    controlLoops.push({
      loopId: `LIC-10${nextNum}`,
      name: `Level Loop ${nextNum}`,
      aiDevice: `LT-10${nextNum}`,
      pidDevice: `LIC-10${nextNum}`,
      aoDevice: `LV-10${nextNum}`,
      aiDurationMs: 25,
      pidDurationMs: 30,
      aoDurationMs: 25
    });
    renderLoopsTable();
  });

  function renderMacrocycleSchedule() {
    const sched = FieldbusScheduler.buildMacrocycleSchedule(controlLoops, 1000);

    document.getElementById('stat-macrocycle').innerText = `${sched.summary.macrocycleMs} ms`;
    document.getElementById('stat-cyclic-time').innerText = `${sched.summary.scheduledTimeMs} ms (${sched.summary.cyclicLoadPercent}%)`;
    document.getElementById('stat-pt-slot').innerText = `${sched.summary.unscheduledSlotMs} ms (${sched.summary.acyclicLoadPercent}%)`;

    const tbody = document.getElementById('tbody-timeline');
    tbody.innerHTML = '';

    sched.scheduledEvents.forEach(e => {
      const tr = document.createElement('tr');
      let typeColor = 'var(--text-primary)';
      if (e.type === 'COMMUNICATION') typeColor = 'var(--orange-accent)';
      if (e.type === 'EXECUTION') typeColor = 'var(--cyan-accent)';
      if (e.type === 'ACYCLIC_SLOT') typeColor = 'var(--emerald-accent)';

      tr.innerHTML = `
        <td><strong>${e.timeOffsetMs} ms</strong></td>
        <td>${e.durationMs} ms</td>
        <td style="color: ${typeColor}; font-weight: 600;">${e.eventType}</td>
        <td>${e.device || 'LAS'}</td>
        <td style="color: var(--text-secondary); font-size: 12px;">${e.description}</td>
      `;
      tbody.appendChild(tr);
    });

    recalculateSegment();
  }

  document.getElementById('btn-recalc-schedule').addEventListener('click', renderMacrocycleSchedule);

  // TAB 3: Segment Voltage Sizer
  function recalculateSegment() {
    const psuVolts = parseFloat(document.getElementById('seg-psu').value) || 24.0;
    const trunkM = parseInt(document.getElementById('seg-trunk').value) || 600;
    const cableType = document.getElementById('seg-cable').value;

    const res = FieldbusSegmentSizer.calculateSegmentVoltage({
      powerConditionerVoltage: psuVolts,
      trunkLengthMeters: trunkM,
      cableType,
      devices: segmentDevices.map(d => ({ currentMa: d.currentMa, spurLengthMeters: d.spurLengthM }))
    });

    document.getElementById('stat-min-voltage').innerText = `${res.minDeviceVoltageV.toFixed(1)} V`;
    document.getElementById('stat-total-current').innerText = `${res.totalCurrentMa} mA`;
    document.getElementById('stat-total-cable').innerText = `${res.totalCableLengthM} m`;

    if (res.isVoltageCompliant) {
      document.getElementById('stat-min-voltage').style.color = 'var(--emerald-accent)';
    } else {
      document.getElementById('stat-min-voltage').style.color = 'var(--rose-accent)';
    }
  }

  document.getElementById('btn-recalc-segment').addEventListener('click', recalculateSegment);

  // TAB 4: Safety Auditor
  function runAudit() {
    const psuVolts = parseFloat(document.getElementById('seg-psu').value) || 24.0;
    const trunkM = parseInt(document.getElementById('seg-trunk').value) || 600;

    const sched = FieldbusScheduler.buildMacrocycleSchedule(controlLoops, 1000);

    const auditRes = FieldbusAuditor.auditSegment({
      devices: segmentDevices,
      trunkLengthM: trunkM,
      cableType: 'TYPE_A',
      psuVoltage: psuVolts,
      terminatorsInstalled: 2,
      macrocycleMs: sched.summary.macrocycleMs,
      cyclicScheduledMs: sched.summary.scheduledTimeMs,
      isFiscoZone1: false
    });

    document.getElementById('audit-score').innerText = `${auditRes.summary.overallScore}/100`;
    document.getElementById('audit-grade').innerText = auditRes.summary.grade;
    document.getElementById('audit-summary-counts').innerText =
      `${auditRes.summary.passCount} Pass / ${auditRes.summary.warnCount} Warn / ${auditRes.summary.failCount} Fail`;

    const container = document.getElementById('audit-results-container');
    container.innerHTML = '';

    auditRes.findings.forEach(f => {
      const rule = auditRes.rules.find(r => r.id === f.id);
      const item = document.createElement('div');
      item.className = 'audit-item';

      let statusClass = 'audit-pass';
      if (f.status === 'WARN') statusClass = 'audit-warn';
      if (f.status === 'FAIL') statusClass = 'audit-fail';

      item.innerHTML = `
        <span class="audit-status ${statusClass}">${f.status}</span>
        <div class="audit-content">
          <h4>[${f.id}] ${rule ? rule.name : f.id} (${rule ? rule.standard : 'STD'})</h4>
          <p>${f.details}</p>
        </div>
      `;
      container.appendChild(item);
    });
  }

  document.getElementById('btn-run-audit').addEventListener('click', runAudit);

  // TAB 5: Exporter
  document.getElementById('btn-generate-export').addEventListener('click', () => {
    const target = document.getElementById('export-target').value;
    const sched = FieldbusScheduler.buildMacrocycleSchedule(controlLoops, 1000);
    let out = '';

    if (target === 'EMERSON_DELTAV') {
      out = `<?xml version="1.0" encoding="UTF-8"?>\n<!-- Emerson DeltaV Fieldbus Segment Definition -->\n<FF_SEGMENT name="SEG_101" macrocycle_ms="${sched.summary.macrocycleMs}">\n`;
      controlLoops.forEach(l => {
        out += `  <LOOP tag="${l.loopId}">\n`;
        out += `    <BLOCK type="AI" device="${l.aiDevice}" duration_ms="${l.aiDurationMs}"/>\n`;
        out += `    <BLOCK type="PID" device="${l.pidDevice}" duration_ms="${l.pidDurationMs}"/>\n`;
        out += `    <BLOCK type="AO" device="${l.aoDevice}" duration_ms="${l.aoDurationMs}"/>\n`;
        out += `  </LOOP>\n`;
      });
      out += `</FF_SEGMENT>\n`;
    } else if (target === 'YOKOGAWA_CENTUM') {
      out = `# Yokogawa CENTUM VP H1 Schedule CSV\nOffset_ms,Duration_ms,Event,Device\n`;
      sched.scheduledEvents.forEach(e => {
        out += `${e.timeOffsetMs},${e.durationMs},"${e.eventType}","${e.device || 'LAS'}"\n`;
      });
    } else if (target === 'PYTHON_SIM') {
      out = `#!/usr/bin/env python3\n# Python 31.25 kbps H1 Virtual Bus Client\nimport struct\n\n`;
      out += `def create_pv_packet(value=75.5, quality_good=True):\n`;
      out += `    # Float32 Big-Endian + 1-byte Status (0x80 = Good Non-Cascade)\n`;
      out += `    status = 0x80 if quality_good else 0x00\n`;
      out += `    return struct.pack('>fB', value, status)\n\n`;
      out += `pv_bytes = create_pv_packet(82.4, True)\n`;
      out += `print("H1 PV Data:", [hex(b) for b in pv_bytes])\n`;
    }

    document.getElementById('export-output').value = out;
  });

  // Init
  renderH1Frame();
  renderLoopsTable();
  recalculateSegment();
  runAudit();
});
