/**
 * FoundationForge Pro - FOUNDATION Fieldbus H1 & LAS Protocol Engine
 * Implements Manchester Biphase-L 31.25 kbps frame structures, Preamble/Delimiters,
 * Link Active Scheduler (LAS) Compelled (CD) / Pass Token (PT) Token Ring scheduling,
 * Standard Function Block Process Value (PV) packing, and 8-bit / 16-bit Frame Check Sequences.
 */

const FieldbusEngine = (function () {
  // Delimiters per IEC 61158-2 Physical Layer
  // Start Delimiter (1 byte): 10101100 pattern with non-data symbols (N+, N-)
  const START_DELIMITER = 0xAC; // Standard representation of SD
  const END_DELIMITER = 0xAD;   // Standard representation of ED

  // LAS Token and Message Types
  const FRAME_TYPES = {
    0x01: { name: 'Compelled Data (CD)', desc: 'Cyclic publisher broadcast trigger from LAS' },
    0x02: { name: 'Pass Token (PT)', desc: 'Acyclic client/server transmission rights token' },
    0x03: { name: 'Time Distribution (TD)', desc: 'Network master clock synchronization message' },
    0x04: { name: 'Probe Node (PN)', desc: 'New device discovery token probe' },
    0x05: { name: 'Return Token (RT)', desc: 'Device returning execution rights to LAS' },
    0x10: { name: 'Data (DT)', desc: 'Unscheduled or scheduled publisher process data message' }
  };

  // Standard Foundation Fieldbus Function Blocks & Execution Execution Durations
  const STANDARD_BLOCKS = {
    AI: {
      name: 'Analog Input (AI)',
      category: 'INPUT',
      typicalPeriodMs: 20,
      description: 'Reads transducer signal, filters, scales, and publishes PV with Status'
    },
    AO: {
      name: 'Analog Output (AO)',
      category: 'OUTPUT',
      typicalPeriodMs: 25,
      description: 'Receives target setpoint, checks shed limits, drives final control element'
    },
    PID: {
      name: 'Proportional Integral Derivative (PID)',
      category: 'CONTROL',
      typicalPeriodMs: 35,
      description: 'Implements feedback loop control with setpoint tracking and anti-reset windup'
    },
    DI: {
      name: 'Discrete Input (DI)',
      category: 'INPUT',
      typicalPeriodMs: 15,
      description: 'Reads discrete switch state or digital input with quality status'
    },
    DO: {
      name: 'Discrete Output (DO)',
      category: 'OUTPUT',
      typicalPeriodMs: 15,
      description: 'Drives discrete solenoid valve or digital contact'
    },
    CS: {
      name: 'Control Selector (CS)',
      category: 'CALC',
      typicalPeriodMs: 25,
      description: 'Selects minimum, maximum, or average signal across multiple inputs'
    }
  };

  // FF H1 Process Variable (PV) Quality Status Byte (Bits 7..0)
  // Quality: Bits 7..6 (00=Bad, 01=Uncertain, 10=Good Non-Cascade, 11=Good Cascade)
  // Sub-status: Bits 5..2
  // Limits: Bits 1..0 (00=Not Limited, 01=Low Limited, 10=High Limited, 11=Constant)
  const STATUS_QUALITY = {
    BAD: 0x00,          // 00xxxxxx
    UNCERTAIN: 0x40,    // 01xxxxxx
    GOOD_NON_CASCADE: 0x80, // 10xxxxxx
    GOOD_CASCADE: 0xC0  // 11xxxxxx
  };

  /**
   * Encodes a standard FF Process Value (Float32 + 1-byte Status = 5 Bytes)
   * @param {number} value - Floating point measurement
   * @param {string} quality - 'GOOD_NON_CASCADE' | 'GOOD_CASCADE' | 'UNCERTAIN' | 'BAD'
   * @param {number} limit - 0=None, 1=Low, 2=High, 3=Constant
   */
  function encodeProcessValue(value, quality = 'GOOD_NON_CASCADE', limit = 0) {
    const buffer = new ArrayBuffer(4);
    const view = new DataView(buffer);
    view.setFloat32(0, value, false); // Big-endian IEEE 754

    const floatBytes = [
      view.getUint8(0),
      view.getUint8(1),
      view.getUint8(2),
      view.getUint8(3)
    ];

    const qBase = STATUS_QUALITY[quality] !== undefined ? STATUS_QUALITY[quality] : STATUS_QUALITY.GOOD_NON_CASCADE;
    const statusByte = (qBase & 0xc0) | (limit & 0x03);

    return {
      bytes: [...floatBytes, statusByte],
      hexString: [...floatBytes, statusByte].map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
      floatValue: value,
      statusByte: `0x${statusByte.toString(16).padStart(2, '0').toUpperCase()}`,
      qualityName: quality,
      isGood: (qBase & 0x80) !== 0
    };
  }

  /**
   * Decodes a 5-byte FF Process Value (4 bytes IEEE-754 float + 1 byte Status)
   */
  function decodeProcessValue(bytes) {
    if (!bytes || bytes.length < 5) {
      throw new Error(`Process Value requires 5 bytes (got ${bytes ? bytes.length : 0})`);
    }

    const buffer = new ArrayBuffer(4);
    const view = new DataView(buffer);
    for (let i = 0; i < 4; i++) {
      view.setUint8(i, bytes[i]);
    }
    const floatVal = view.getFloat32(0, false); // Big-endian
    const statusByte = bytes[4];

    const qBits = (statusByte >> 6) & 0x03;
    let qName = 'BAD';
    if (qBits === 1) qName = 'UNCERTAIN';
    else if (qBits === 2) qName = 'GOOD_NON_CASCADE';
    else if (qBits === 3) qName = 'GOOD_CASCADE';

    const limitBits = statusByte & 0x03;
    let limitName = 'NOT_LIMITED';
    if (limitBits === 1) limitName = 'LOW_LIMITED';
    else if (limitBits === 2) limitName = 'HIGH_LIMITED';
    else if (limitBits === 3) limitName = 'CONSTANT';

    return {
      value: parseFloat(floatVal.toFixed(4)),
      statusByte: `0x${statusByte.toString(16).padStart(2, '0').toUpperCase()}`,
      quality: qName,
      limits: limitName,
      isGood: qBits >= 2
    };
  }

  /**
   * Calculates CRC-16 for Foundation Fieldbus H1 Frame (Polynomial: x^16 + x^12 + x^5 + 1 -> 0x1021)
   */
  function calculateFrameFcs(dataBytes) {
    let crc = 0xFFFF;
    for (const b of dataBytes) {
      crc ^= (b << 8);
      for (let i = 0; i < 8; i++) {
        if (crc & 0x8000) {
          crc = ((crc << 1) ^ 0x1021) & 0xFFFF;
        } else {
          crc = (crc << 1) & 0xFFFF;
        }
      }
    }
    return crc ^ 0xFFFF; // Final XOR
  }

  /**
   * Builds an H1 Frame (Preamble + SD + Control + Dst + Src + Payload + FCS + ED)
   */
  function buildH1Frame(options) {
    const opts = Object.assign({
      frameType: 0x01,     // Compelled Data (CD)
      destAddress: 0x14,   // Field Device Address (0x10..0xF7)
      srcAddress: 0x01,    // LAS Address (0x01..0x0F)
      payload: [0x42, 0x96, 0x00, 0x00, 0x80] // Sample 75.0 Float + Good Status
    }, options);

    const controlByte = opts.frameType & 0xff;
    const coreData = [controlByte, opts.destAddress & 0xff, opts.srcAddress & 0xff, ...(opts.payload || [])];
    const fcs = calculateFrameFcs(coreData);
    const fcsBytes = [(fcs >> 8) & 0xff, fcs & 0xff];

    const fullFrame = [
      0x55, 0x55,          // 2-byte Preamble (10101010...)
      START_DELIMITER,     // 0xAC Start Delimiter
      ...coreData,         // Control + Addresses + Payload
      ...fcsBytes,         // 2-byte CRC-16 FCS
      END_DELIMITER        // 0xAD End Delimiter
    ];

    const frameMeta = FRAME_TYPES[opts.frameType] || { name: 'Unknown Frame', desc: '' };

    return {
      bytes: fullFrame,
      hexString: fullFrame.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
      fcs: `0x${fcs.toString(16).padStart(4, '0').toUpperCase()}`,
      fcsValue: fcs,
      frameTypeName: frameMeta.name,
      destAddressHex: `0x${opts.destAddress.toString(16).padStart(2, '0').toUpperCase()}`,
      srcAddressHex: `0x${opts.srcAddress.toString(16).padStart(2, '0').toUpperCase()}`,
      byteLength: fullFrame.length,
      durationMs: parseFloat(((fullFrame.length * 8) / 31.25).toFixed(2)) // 31.25 bits/ms
    };
  }

  /**
   * Dissects an incoming H1 Hex string
   */
  function dissectH1Frame(hexStr) {
    const cleanHex = hexStr.replace(/[^0-9a-fA-F]/g, '');
    const bytes = [];
    for (let i = 0; i < cleanHex.length; i += 2) {
      bytes.push(parseInt(cleanHex.substr(i, 2), 16));
    }

    if (bytes.length < 8) {
      throw new Error(`Frame too short for H1 dissection (${bytes.length} bytes, minimum 8 required)`);
    }

    // Locate Start Delimiter
    const sdIndex = bytes.indexOf(START_DELIMITER);
    const edIndex = bytes.lastIndexOf(END_DELIMITER);

    if (sdIndex === -1 || edIndex === -1 || edIndex <= sdIndex + 5) {
      throw new Error("Invalid H1 framing: Missing Start (0xAC) or End (0xAD) delimiter.");
    }

    const coreData = bytes.slice(sdIndex + 1, edIndex - 2);
    const receivedFcs = (bytes[edIndex - 2] << 8) | bytes[edIndex - 1];
    const computedFcs = calculateFrameFcs(coreData);
    const isFcsValid = (receivedFcs === computedFcs);

    const frameType = coreData[0];
    const dstAddr = coreData[1];
    const srcAddr = coreData[2];
    const payload = coreData.slice(3);

    const typeMeta = FRAME_TYPES[frameType] || { name: 'Unknown Frame', desc: '' };

    return {
      frameTypeHex: `0x${frameType.toString(16).padStart(2, '0').toUpperCase()}`,
      frameTypeName: typeMeta.name,
      destAddress: `0x${dstAddr.toString(16).padStart(2, '0').toUpperCase()} (${dstAddr})`,
      srcAddress: `0x${srcAddr.toString(16).padStart(2, '0').toUpperCase()} (${srcAddr})`,
      payloadBytes: payload,
      payloadHex: payload.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' '),
      receivedFcs: `0x${receivedFcs.toString(16).padStart(4, '0').toUpperCase()}`,
      computedFcs: `0x${computedFcs.toString(16).padStart(4, '0').toUpperCase()}`,
      isFcsValid,
      totalLength: bytes.length
    };
  }

  return {
    START_DELIMITER,
    END_DELIMITER,
    FRAME_TYPES,
    STANDARD_BLOCKS,
    STATUS_QUALITY,
    encodeProcessValue,
    decodeProcessValue,
    calculateFrameFcs,
    buildH1Frame,
    dissectH1Frame
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FieldbusEngine;
}
