/**
 * FoundationForge Pro - Physical Segment Design & Intrinsic Safety Sizer
 * Calculates Type A cable loop resistance (44 ohm/km), DC voltage drops across
 * field barriers / power conditioners (e.g. 24V DC source, min 9.0V DC at device),
 * individual and cumulative spur length limits, and FISCO / Entity model limits.
 */

const FieldbusSegmentSizer = (function () {
  // Cable Standards per IEC 61158-2
  const CABLE_TYPES = {
    TYPE_A: {
      name: 'Type A Cable (Shielded Twisted Pair, 18 AWG / 0.8 mm²)',
      loopResistanceOhmPerKm: 44.0, // 22 ohm/km per conductor
      maxTrunkMeters: 1900,
      attenuationDbPerKm: 3.0
    },
    TYPE_B: {
      name: 'Type B Cable (Multiple Twisted Pairs, Overall Shield, 22 AWG / 0.32 mm²)',
      loopResistanceOhmPerKm: 112.0,
      maxTrunkMeters: 1200,
      attenuationDbPerKm: 5.0
    },
    TYPE_C: {
      name: 'Type C Cable (Multi-pair unshielded, 26 AWG / 0.13 mm²)',
      loopResistanceOhmPerKm: 264.0,
      maxTrunkMeters: 400,
      attenuationDbPerKm: 8.0
    }
  };

  /**
   * Maximum Spur Length Allowed Based on Number of Connected Devices per IEC 61158-2
   * Table 10 Spur Length Budget:
   * 1-12 Devices: 120m max per spur
   * 13-14 Devices: 90m max per spur
   * 15-18 Devices: 60m max per spur
   * 19-24 Devices: 30m max per spur
   * 25-32 Devices: 1m max per spur (bus connections)
   */
  function getMaxSpurLengthAllowed(deviceCount) {
    if (deviceCount <= 12) return 120;
    if (deviceCount <= 14) return 90;
    if (deviceCount <= 18) return 60;
    if (deviceCount <= 24) return 30;
    return 1;
  }

  /**
   * Calculates Segment Voltage Drops and Current Demands
   * @param {Object} params - {
   *   powerConditionerVoltage: 24.0 (V DC),
   *   trunkLengthMeters: 800,
   *   cableType: 'TYPE_A',
   *   devices: [ { name, currentMa, spurLengthMeters } ]
   * }
   */
  function calculateSegmentVoltage(params) {
    const psuVolts = params.powerConditionerVoltage || 24.0;
    const trunkM = params.trunkLengthMeters || 600;
    const cable = CABLE_TYPES[params.cableType] || CABLE_TYPES.TYPE_A;
    const devices = params.devices || [];

    const totalDevices = devices.length;
    let totalCurrentMa = 0;
    let totalSpurLengthM = 0;
    let longestSpurM = 0;

    devices.forEach(d => {
      const ma = d.currentMa || 20.0; // Typical 15-24 mA per smart fieldbus transmitter
      const spurM = d.spurLengthMeters || 30.0;
      totalCurrentMa += ma;
      totalSpurLengthM += spurM;
      if (spurM > longestSpurM) longestSpurM = spurM;
    });

    const totalCurrentAmps = totalCurrentMa / 1000.0;

    // Trunk Resistance: (trunkM / 1000) * loopResistance
    const trunkResistanceOhm = (trunkM / 1000.0) * cable.loopResistanceOhmPerKm;
    const trunkVoltageDropV = totalCurrentAmps * trunkResistanceOhm;
    const voltageAtTrunkEndV = psuVolts - trunkVoltageDropV;

    // Worst-case device: end of trunk + longest spur
    const spurResistanceOhm = (longestSpurM / 1000.0) * cable.loopResistanceOhmPerKm;
    // Current in worst spur is that device's current (~20-25 mA)
    const worstDeviceMa = devices.length > 0 ? (devices[0].currentMa || 20.0) : 20.0;
    const spurVoltageDropV = (worstDeviceMa / 1000.0) * spurResistanceOhm;
    const minDeviceVoltageV = parseFloat((voltageAtTrunkEndV - spurVoltageDropV).toFixed(2));

    const totalCableLengthM = trunkM + totalSpurLengthM;
    const maxSpurLimit = getMaxSpurLengthAllowed(totalDevices);

    return {
      psuVoltage: psuVolts,
      totalCurrentMa: Math.round(totalCurrentMa),
      totalCurrentAmps: parseFloat(totalCurrentAmps.toFixed(3)),
      trunkLengthM: trunkM,
      totalCableLengthM,
      maxAllowedTrunkM: cable.maxTrunkMeters,
      trunkVoltageDropV: parseFloat(trunkVoltageDropV.toFixed(2)),
      voltageAtTrunkEndV: parseFloat(voltageAtTrunkEndV.toFixed(2)),
      minDeviceVoltageV,
      isVoltageCompliant: minDeviceVoltageV >= 9.0, // Minimum operational voltage per IEC 61158-2
      longestSpurM,
      maxAllowedSpurM: maxSpurLimit,
      isSpurLengthCompliant: longestSpurM <= maxSpurLimit,
      isTotalLengthCompliant: totalCableLengthM <= cable.maxTrunkMeters,
      totalDevices
    };
  }

  return {
    CABLE_TYPES,
    getMaxSpurLengthAllowed,
    calculateSegmentVoltage
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FieldbusSegmentSizer;
}
